package {PACKAGE_NAME}.ui.activity

import {PACKAGE_NAME}.databinding.ActivityMainBinding
import {PACKAGE_NAME}.ui.activity.base.BaseActivity

class MainActivity : BaseActivity<ActivityMainBinding>() {

    override fun onCreate() {
        // Your code here.
    }
}