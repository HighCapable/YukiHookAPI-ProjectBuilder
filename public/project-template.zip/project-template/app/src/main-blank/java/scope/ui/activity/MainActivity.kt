package {PACKAGE_NAME}.ui.activity

import android.os.Bundle
import android.widget.LinearLayout
import com.highcapable.betterandroid.ui.component.activity.AppViewsActivity
import com.highcapable.hikage.extension.setContentView
import com.highcapable.hikage.widget.android.widget.LinearLayout
import com.highcapable.hikage.widget.com.google.android.material.appbar.MaterialToolbar
import {PACKAGE_NAME}.R
import android.R as Android_R

class MainActivity : AppViewsActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Base activity background
        findViewById<View>(Android_R.id.content).setBackgroundResource(R.color.colorThemeBackground)

        // UI view based on Hikage DSL
        // See: https://github.com/BetterAndroid/Hikage
        setContentView {
            LinearLayout(
                lparams = LayoutParams(widthMatchParent = true),
                init = {
                    orientation = LinearLayout.VERTICAL
                }
            ) {
                MaterialToolbar(
                    lparams = LayoutParams(widthMatchParent = true),
                    init = {
                        title = stringResource(R.string.app_name)
                    }
                )
                // Your code here.
            }
        }
    }
}